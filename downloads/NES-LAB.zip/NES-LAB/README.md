# NES LAB

Pierwsza wersja laboratorium analizy ROM-ów NES. Python 3.12+, bez zewnętrznych zależności, CDN, bazy danych i kluczy API.

```sh
cd /workspace/zgielk
python -m neslab.server --host 0.0.0.0 --port 8000
```

Przy uruchomieniu na własnym komputerze otwórz adres podany w terminalu. Na Windows, jeśli polecenie `python` nie działa, użyj `py -m neslab.server --port 8000`. Nie otwieraj `web/index.html` bezpośrednio ani przez Live Server: analiza wymaga API serwera NES LAB. Strona sprawdza jego dostępność i pokazuje instrukcję przy braku połączenia.

Po wybraniu ROM-u aplikacja pokazuje raport i kafelki grafiki. Nie odtwarza gry — nie zawiera jeszcze emulatora.

W aplikacji wybierz plik `.nes` (maksymalnie 32 MiB). Plik trafia do serwera aplikacji, jest analizowany w pamięci i nie jest zapisywany na dysku. Serwer przeznaczony do lokalnego rozwoju, bez uwierzytelniania.

## Dostępne funkcje

- Nagłówki iNES i NES 2.0, mapper/submapper, deklarowane rozmiary i mirroring.
- Bezstratny podział: nagłówek, trainer, PRG-ROM, CHR-ROM i dane dodatkowe; SHA-256.
- Podgląd pierwszego banku CHR; eksport wszystkich banków jako PNG w umownej skali szarości.
- Kandydaci na ciągi ASCII i wektory NMI/RESET/IRQ dla standardowego NROM.
- ZIP: oryginalny plik, wszystkie surowe sekcje, raport JSON i grafika.

## Granice i kierunek rozwoju

Wszystkie bajty są zachowane. Nie oznacza to rozpoznania ich znaczenia. Kafelki CHR nie są automatycznie sprite’ami ani animacjami. Grafika z CHR-RAM, kompresja, własne kodowania tekstu, poziomy, mechaniki, fizyka i skrypty wymagają analizy konkretnej gry.

Następne etapy: deasemblacja 6502 z rozróżnianiem kodu i danych, obsługa mapowania banków, ślady CPU/PPU z emulatora, anotacje i dekodery dla konkretnych gier. Rekonstrukcja w innym języku wymaga porównań klatka po klatce, stanów i dźwięku; sam statyczny eksport tego nie zapewnia. Ta wersja nie wykonuje ROM-ów i nie deklaruje zgodności odtworzonej gry 1:1.

## Weryfikacja

```sh
python -m unittest discover -s tests -v
```

Testy używają syntetycznych ROM-ów: warianty nagłówka, rozmiary wykładnicze NES 2.0, trainer, pliki ucięte, wektory, ciągi ASCII, bezstratny ZIP i dekodowanie bitplanów PNG wraz z CRC.
