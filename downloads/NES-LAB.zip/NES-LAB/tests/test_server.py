import io
import json
import threading
import unittest
import urllib.error
import urllib.request
import zipfile
from http.server import ThreadingHTTPServer
from neslab.server import Handler
from test_rom import fixture


class ServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f'http://127.0.0.1:{cls.server.server_port}'

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()

    def test_health_and_assets(self):
        with urllib.request.urlopen(self.base + '/api/health') as response:
            self.assertEqual(json.load(response)['app'], 'neslab')
        with urllib.request.urlopen(self.base + '/app.js?v=2') as response:
            self.assertIn(b'initialize()', response.read())

    def test_analysis_upload(self):
        with urllib.request.urlopen(self.base + '/api/analyze', data=fixture()) as response:
            self.assertEqual(json.load(response)['tiles'], 512)

    def test_invalid_upload(self):
        with self.assertRaises(urllib.error.HTTPError) as error:
            urllib.request.urlopen(self.base + '/api/analyze', data=b'bad')
        self.assertEqual(error.exception.code, 400)
        self.assertIn('error', json.load(error.exception))

    def test_export(self):
        data = fixture()
        with urllib.request.urlopen(self.base + '/api/export', data=data) as response:
            self.assertEqual(response.headers.get_content_type(), 'application/zip')
            with zipfile.ZipFile(io.BytesIO(response.read())) as archive:
                self.assertEqual(archive.read('original.nes'), data)
